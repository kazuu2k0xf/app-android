package com.example.epoka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity {

    TextView tvTitre, tvNewMission;
    Button btnAddMission, btnQuitter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        init();
    }

    public void init() {
        setControl();
        setAction();

        tvNewMission.setText("Bonjour " + getUsername());
        getNumero();
    }
    public void setControl(){
        tvTitre = findViewById(R.id.tvTitre);
        tvNewMission = findViewById(R.id.tvNewMission);
        btnAddMission = findViewById(R.id.btnAddMission);
        btnQuitter = findViewById(R.id.btnQuitter);
    }
    public void setAction() {
        btnAddMission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenIntent(MissionActivity.class);
                Intent intent = new Intent(getApplicationContext(), MissionActivity.class);
                intent.putExtra("num", getNumero());


                startActivity(intent);

            }
        });
        btnQuitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });
    }
    public String getUsername() {
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");

        return username;
    }

    public String getNumero() {
        Intent intent = getIntent();
        String numero = intent.getStringExtra("num");

        return numero;
    }
    public void OpenIntent(Class myClass){
        Intent intent = new Intent(MenuActivity.this, myClass);
        startActivity(intent);
    }



}