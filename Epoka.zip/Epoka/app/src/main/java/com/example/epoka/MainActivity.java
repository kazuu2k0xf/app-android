package com.example.epoka;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView tvTitre, tvId, tvNo, tvMdp;
    EditText etNo, etMdp;
    Button btnConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    public void init() {
        setControl();
        setAction();
    }
    public void setControl(){
        tvTitre = findViewById(R.id.tvTitre);
        tvId = findViewById(R.id.tvId);
        tvNo = findViewById(R.id.tvNo);
        tvMdp = findViewById(R.id.tvMdp);
        etNo = findViewById(R.id.etNo);
        etMdp = findViewById(R.id.etMdp);
        btnConnection = findViewById(R.id.btnConnection);
    }

    public void setAction() {
        btnConnection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();

            }
        });
    }

    public void OpenIntent(Class myClass){
        Intent intent = new Intent(MainActivity.this, myClass);
        startActivity(intent);
    }

    public void login() {
        String mdp = etMdp.getText().toString();
        String no = etNo.getText().toString();
        String urlServiceWeb = "http://172.16.47.16/epoka/auth.php?numero=" + no + "&mdp=" + mdp;
        String username = getServerDataTextBrut(urlServiceWeb);

        if (!username.isEmpty()) {

            Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
            intent.putExtra("username",username);
            intent.putExtra("num",no);


            startActivity(intent);


        }
    }

    private String getServerDataTextBrut(String urlAJoindre) {
        //Autoriser les opérations sur le thread principal
        String res = " ";
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        URL url = null;
        try {
            url = new URL(urlAJoindre);

            HttpURLConnection connexion = (HttpURLConnection) url.openConnection();
            connexion.connect();
            InputStream inputStream = connexion.getInputStream();


            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String ligne;
            while ((ligne = bufferedReader.readLine()) != null) {
                res = ligne ;
            }
        } catch (Exception e) {
            Log.d("MyApp", "Erreur échange avec serveur :" + e.toString());

        }
        return res;

    }

}