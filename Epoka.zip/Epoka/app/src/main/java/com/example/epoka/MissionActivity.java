package com.example.epoka;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

public class MissionActivity extends AppCompatActivity {

    TextView tvTitre, tvNewMission, tvDateDebut, tvDateFin, tvDestination;
    EditText etDateDebut, etDateFin, etVille;
    Spinner spCommunes;
    Button btnSubmit;

    String debut;
    String fin;
    private boolean isSpinnerSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission);

        init();
    }

    @SuppressLint("ClickableViewAccessibility")
    public void setAction() {
        etVille.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!isSpinnerSelected) {
                    afficherSpinner();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        spCommunes.setOnTouchListener((v, event) -> {
            isSpinnerSelected = true;
            return false;
        });

        spCommunes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isSpinnerSelected) {
                    String selectedItem = parent.getItemAtPosition(position).toString();
                    etVille.setText(selectedItem);
                    isSpinnerSelected = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newMission();

            }
        });
    }
    public void init() {
        setControl();
        setAction();
    }
    public void setControl(){
        tvTitre = findViewById(R.id.tvTitre);
        tvNewMission = findViewById(R.id.tvNewMission);
        tvDateDebut = findViewById(R.id.tvDateDebut);
        tvDateFin = findViewById(R.id.tvDateFin);
        tvDestination = findViewById(R.id.tvDestination);
        spCommunes = findViewById(R.id.spCommunes);
        btnSubmit = findViewById(R.id.btnSubmit);
        etDateDebut = findViewById(R.id.etDateDebut);
        etDateFin = findViewById(R.id.etDateFin);
        etVille = findViewById(R.id.etVille);
    }
    public void afficherSpinner() {
        String ville = etVille.getText().toString();
        String urlServiceWeb = "http://172.16.47.16/epoka/ville.php?ville=" + ville;
        String result = getServerDataTextBrut(urlServiceWeb);
        remplirSpinner(result);
    }
    private String getServerDataTextBrut(String urlAJoindre) {

        StringBuilder res = new StringBuilder();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            URL url = new URL(urlAJoindre);
            HttpURLConnection connexion = (HttpURLConnection) url.openConnection();
            connexion.connect();
            InputStream inputStream = connexion.getInputStream();

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String ligne;
            while ((ligne = bufferedReader.readLine()) != null) {
                res.append(ligne).append("\n");
            }
        } catch (Exception e) {
            Log.d("MyApp", "Erreur échange avec serveur :" + e.toString());
        }

        return res.toString();
    }
    private void remplirSpinner(String result) {
        String[] lines = result.split("\n");
        ArrayList<String> villes = new ArrayList<>();

        for (String line : lines) {
            if (!line.trim().isEmpty()) {
                String[] parts = line.split("(?<=\\D)(?=\\d)");
                if (parts.length >= 1) {
                    String villeName = parts[0].trim();
                    String codePostal = parts[1].trim();
                    villes.add(villeName + " (" + codePostal + ")");
                } else {
                    villes.add(line.trim());
                }
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, villes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCommunes.setAdapter(adapter);
    }
    private String getVilleNo(String ville) {
         ville = etVille.getText().toString();
         ville = ville.substring(0, ville.indexOf(" "));
        String urlServiceWeb = "http://172.16.47.16/epoka/villeno.php?ville=" + ville;
        String result = getServerDataTextBrut(urlServiceWeb);

        return result;
    }

    public String getUsername() {
        Intent intent = getIntent();
        String no = intent.getStringExtra("num");

        return no;
    }
    public void newMission() {
        debut = etDateDebut.getText().toString();
        fin = etDateFin.getText().toString();
        String num = getUsername();
        String ville = getVilleNo(etVille.getText().toString());


        String urlServiceWeb = "http://172.16.47.16/epoka/mission.php?numero=" + num + "&ville=" + ville + "&debut=" + debut + "&fin=" + fin;
        getServerDataTextBrut(urlServiceWeb);

        Snackbar.make(findViewById(android.R.id.content), "Enregistrement effectué", Snackbar.LENGTH_LONG).show();

    }


}

